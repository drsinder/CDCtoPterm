Download and install dotnet core 2.0.3 runtime:

https://www.microsoft.com/net/download/windows

https://www.microsoft.com/net/download/linux

https://www.microsoft.com/net/download/mac

To convert a disk:

dotnet CDCtoPterm.dll inputpath outputpath